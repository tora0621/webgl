<?php

namespace ACP\Column\Media;

use ACP;

class Menu extends ACP\Column\Post\Menu {

}